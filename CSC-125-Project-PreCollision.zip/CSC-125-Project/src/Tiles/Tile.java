package Tiles;

import java.awt.image.BufferedImage;

//Represents single tile
public class Tile {

    public BufferedImage image;
    public boolean collision = false;



}
