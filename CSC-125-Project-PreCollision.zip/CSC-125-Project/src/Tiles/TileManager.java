package Tiles;

import Main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Objects;

public class TileManager {

    GamePanel gp;
    public Tile[] tile;

    public int mapTileNum[][];                                          //creates a 2 dimensional array

/**************************************************| Tile Settings |***************************************************/

    public TileManager(GamePanel gp){

        this.gp = gp;

        tile = new Tile[22];                                             /**Change Number to Change Max Tiles Allowed**/

        mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];

        getTileImage();     //gets image
        loadMap("/Resources/Maps/world.txt");                 /**Change .tct File To Change What Map To Use**/
    }

/*****************************************| Get Tile Images From Resources |*******************************************/

    public void getTileImage(){                     //constructs and finds new tiles and tile .png location

        try{
        tile[0] = new Tile();
        tile[0].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/grass.png"));

        tile[1] = new Tile();
        tile[1].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/fenceHorizontal.png"));

        tile[2] = new Tile();
        tile[2].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/fenceVertical.png"));

        tile[3] = new Tile();
        tile[3].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/soil.png"));

        tile[4] = new Tile();
        tile[4].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[5] = new Tile();
        tile[5].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[6] = new Tile();
        tile[6].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[7] = new Tile();
        tile[7].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[8] = new Tile();
        tile[8].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[9] = new Tile();
        tile[9].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[10] = new Tile();
        tile[10].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[11] = new Tile();
        tile[11].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[12] = new Tile();
        tile[12].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[13] = new Tile();
        tile[13].image = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Resources/LandSprites/")));

        tile[14] = new Tile();
        tile[14].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[15] = new Tile();
        tile[15].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[16] = new Tile();
        tile[16].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[17] = new Tile();
        tile[17].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[18] = new Tile();
        tile[18].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[19] = new Tile();
        tile[19].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        tile[20] = new Tile();
        tile[20].image = ImageIO.read(getClass().getResourceAsStream("/Resources/LandSprites/"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }

/****************************************| Convert Text File Into Map Data |*******************************************/

public void loadMap(String mapchoice){                                     //LOADS MAP TEXT FILE INTO GAME

        try{
            InputStream is = getClass().getResourceAsStream(mapchoice);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int col = 0;
            int row = 0;

            while(col < gp.maxWorldCol && row < gp.maxWorldRow){               //while loop to go through values in .txt

                String line = br.readLine();                                   //READS LINE OF TEXT FROM TEXT FILE

                while(col < gp.maxWorldCol){                                   //second while loop to change columns

                    String numbers[] = line.split(" ");                  //continues to read with spaces
                    int num = Integer.parseInt(numbers[col]);

                    mapTileNum[col][row] = num;
                    col++;
                }
                if(col == gp.maxWorldCol){
                    col = 0;
                    row++;
                }
            }
            br.close();

        } catch(Exception e){}
    }

/************************************| Draw Graphics From Images and Map Data |****************************************/

    public void draw(Graphics2D g2){

    int worldCol = 0;
    int worldRow = 0;


    while(worldCol < gp.maxWorldCol && worldRow < gp.maxWorldRow){

        int tileNum = mapTileNum[worldCol][worldRow];      //Gives us which tile to display

        int WorldX = worldCol * gp.tileSize;               //sets World x position
        int WorldY = worldRow * gp.tileSize;               //sets World y position

        int ScreenX = WorldX - gp.player.worldX + gp.player.screenX;
        int ScreenY = WorldY - gp.player.worldY + gp.player.screenY;

        g2.drawImage(tile[tileNum].image, ScreenX, ScreenY, gp.tileSize, gp.tileSize, null);  //draws from.txt

        worldCol++;


        if (worldCol == gp.maxWorldCol){
            worldCol = 0;

            worldRow++;

        }
    }
    }

}
